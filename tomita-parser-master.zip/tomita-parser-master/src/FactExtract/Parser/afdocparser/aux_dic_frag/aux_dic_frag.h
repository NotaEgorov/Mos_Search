#pragma once

Stroka GetAuxDicByName(const Stroka& fileName);
