#pragma once

#include <kernel/gazetteer/builtin.h>

const NGzt::NBuiltin::TFileCollection& TomitaBuiltinProtos();
