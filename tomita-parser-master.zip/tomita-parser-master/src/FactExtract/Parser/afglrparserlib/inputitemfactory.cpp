#include "inputitemfactory.h"
#include <FactExtract/Parser/common/inputitem.h>

CInputItemFactory::CInputItemFactory(void)
{
    m_iCurStartWord = 0;
}

CInputItemFactory::~CInputItemFactory(void)
{
}
