/* The following code is the modified part of the libiconv
 * available at http://www.gnu.org/software/libiconv/
 * under the terms of the GNU Lesser General Public License v. 2
 * http://www.gnu.org/licenses/lgpl.html
 */

S(osf1_0, "DEC-KANJI", ei_dec_kanji )
  S(osf1_1, "DEC-HANYU", ei_dec_hanyu )
