/* The following code is the modified part of the libiconv
 * available at http://www.gnu.org/software/libiconv/
 * under the terms of the GNU Lesser General Public License v. 2
 * http://www.gnu.org/licenses/lgpl.html
 */

(int)(long)&((struct stringpool2_t *)0)->stringpool_dos_0,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_4,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_5,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_8,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_12,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_13,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_17,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_21,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_22,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_26,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_31,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_35,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_38,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_42,
  (int)(long)&((struct stringpool2_t *)0)->stringpool_dos_47,
